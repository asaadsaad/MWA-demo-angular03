import { Component } from '@angular/core';

@Component({
  selector: 'eager',
  template: `<p>Eager Component ;)</p>`,
})
export class EagerComponent { }
