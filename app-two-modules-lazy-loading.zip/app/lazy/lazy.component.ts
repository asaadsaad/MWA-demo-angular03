import { Component } from '@angular/core';

@Component({
  selector: 'lazy',
  template: `<p>Lazy Component ;)</p>`,
})
export class LazyComponent { }
