import { Component, } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <p>
      Child Component!
    </p>
  `
})
export class ChildComponent {

}
